<?php echo e($slot); ?>: <?php echo e($url); ?>

<?php /**PATH C:\Users\maxim\OneDrive\Рабочий стол\git1\my-audio-lib\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/button.blade.php ENDPATH**/ ?>