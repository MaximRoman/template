

<?php $__env->startSection('content'); ?>
    <div class="card border-0 h-100 rounded-0 bg-gray">
        <div class="card-body">
            <h3 class="text-center">Добавьте новую книгу :</h3>
            <form class="form-group row justify-content-center gap-3" action=<?php echo e(route('createBook')); ?> method="POST">
                <?php echo csrf_field(); ?>
                <div class="col-7 d-flex flex-column align-items-start gap-2">
                    <label >Обложка</label>
                    <?php if(isset($image)): ?>
                        <?php $__currentLoopData = $image; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <img class="img-fluid" src="<?php echo e(asset('/storage/' . $item->image)); ?>">
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <a class="btn btn-warning" href="/add-book/select-image"><i class="fa-solid fa-pen"></i></a>             
                    <?php else: ?>
                        <a class="btn btn-success" href="/add-book/select-image"><i class="fa-solid fa-plus"></i></a>
                    <?php endif; ?>        
                </div>
                <div class="col-7">
                    <label for="title">Название</label>
                    <input class="form-control bg-secondary text-light <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" type="text" name="title" id="title">
                    <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="invalid-feedback" role="alert">
                            <strong><?php echo e($message); ?></strong>
                        </span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="col-7 d-flex flex-column align-items-start">
                    <label for="authors">Автор</label>
                    <?php if(isset($authors)): ?>
                        <?php if(count($authors) > 0): ?>
                            <div class="d-flex flex-warp mw-100 gap-1">
                                <?php $__currentLoopData = $authors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <span class="h4 text-success"><?php echo e($item->author); ?></span>
                                    <?php if($key < count($authors) - 1): ?>
                                        <span class="h4">/</span>
                                    <?php endif; ?>                              
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                            <a class="btn btn-warning" id="authors" href="/add-book/select-author"><i class="fa-solid fa-pen"></i></a>
                        <?php else: ?>
                        <a class="btn btn-success" id="authors" href="/add-book/select-author"><i class="fa-solid fa-plus"></i></a>
                        <?php endif; ?>
                    <?php endif; ?>
                </div>
                <div class="col-7 d-flex flex-column align-items-start">
                    <label for="readers">Читает</label>
                    <?php if(isset($readers)): ?>
                        <?php if(count($readers) > 0): ?>
                            <div class="d-flex flex-warp mw-100">
                                <?php $__currentLoopData = $readers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <span><?php echo e($item->reader); ?> /</span>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                            <a class="btn btn-warning" id="readers" href="/add-book/select-reader"><i class="fa-solid fa-pen"></i></a>
                        <?php else: ?>
                            <a class="btn btn-success" id="readers" href="/add-book/select-reader"><i class="fa-solid fa-plus"></i></a>
                        <?php endif; ?>
                    <?php endif; ?>
                </div>
                <div class="col-7">
                    <label for="year">Год издания</label>
                    <input class="form-control bg-secondary text-light <?php $__errorArgs = ['year'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" type="number" name="year" id="year">
                    <?php $__errorArgs = ['year'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="invalid-feedback" role="alert">
                            <strong><?php echo e($message); ?></strong>
                        </span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="col-7 d-flex flex-column align-items-start">
                    <label for="series">Цыкл</label>
                    <select class="w-100 form-select bg-secondary text-light" name="series" id="series">
                        <?php if(isset($series)): ?>
                            <?php $__currentLoopData = $series; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($item->id); ?>"><?php echo e($item->series); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                    </select>
                    <div class="d-flex gap-2 mt-2">
                        <a class="btn btn-warning" href="/edit-series"><i class="fa-solid fa-pen"></i></a>
                        <a class="btn btn-success" href="/add-book/add-series"><i class="fa-solid fa-plus"></i></a>
                    </div>
                </div>
                <div class="col-7 d-flex flex-column align-items-start">
                    <label for="categories">Категория</label>
                    <div class="d-flex flex-warp mw-100">
                        <?php if(isset($categories)): ?>
                            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <span><?php echo e($item->category); ?> /</span>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                    </div>
                    <a class="btn btn-success" id="categories" href="/add-book/select-category"><i class="fa-solid fa-plus"></i></a>
                </div>
                <div class="col-7">
                    <label for="description">Описание</label>
                    <textarea class="form-control bg-secondary text-light <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="description" id="description" cols="30" rows="10"></textarea>
                    <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="invalid-feedback" role="alert">
                            <strong><?php echo e($message); ?></strong>
                        </span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="col-7">
                    <label>Аудио Файлы Книги</label>
                    <multy-upload ></multy-upload>
                </div>
                <button type="submit" class="col-6 btn btn-success">Далее</button>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\maxim\OneDrive\Рабочий стол\с\laravel\resources\views/add-book.blade.php ENDPATH**/ ?>