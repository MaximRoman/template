

<?php $__env->startSection('content'); ?>
    <div class="card border-0 h-100 rounded-0 bg-gray">
        <div class="card-body">
            <h3 class="text-center">Выбор Читателей Книги : </h3>
            <?php if(isset($bookId)): ?>
                <div class="h3 d-flex justify-content-between">
                    <a class="btn btn-success" href="/edit-book/<?php echo e($bookId); ?>"><i class="fa-solid fa-arrow-left"></i></a>
                    <a class="btn btn-success" href="/add-reader"><i class="fa-solid fa-plus"></i></a>
                </div>
            <?php else: ?>
                <div class="h3 d-flex justify-content-between">
                    <a class="btn btn-success" href="/add-book"><i class="fa-solid fa-arrow-left"></i></a>
                    <a class="btn btn-success" href="/add-reader"><i class="fa-solid fa-plus"></i></a>
                </div>
            <?php endif; ?>
            <?php if(isset($readers)): ?>
            
                <?php if(isset($bookId)): ?>
                    <form class="row gap-3 justify-content-center mt-3" action="/edit-book/<?php echo e($bookId); ?>/select-book-reader" method="POST">
                <?php else: ?>
                    <form class="row gap-3 justify-content-center mt-3" action=<?php echo e(route('selectBookReader')); ?> method="POST">
                <?php endif; ?>
                    <?php echo csrf_field(); ?>
                    <ul class="col-7 list-group bg-secondary p-3">
                        <label class="col-7">Список Читателей :</label>
                        <?php $__currentLoopData = $readers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li class="list-group-item bg-gray text-light d-flex justify-content-between mt-2 rounded" id="li-<?php echo e($item->id); ?>" 
                                onclick="
                                    document.getElementById('reader-<?php echo e($item->id); ?>').click(); 
                                    if (document.getElementById('reader-<?php echo e($item->id); ?>').checked) {
                                        document.getElementById('li-<?php echo e($item->id); ?>').classList.add('active');
                                    } else {
                                        document.getElementById('li-<?php echo e($item->id); ?>').classList.remove('active');
                                    }"
                            >
                                <span><?php echo e($item->reader); ?></span>
                                <input class="form-check-input" type="checkbox" name="readers[]" id="reader-<?php echo e($item->id); ?>" value="<?php echo e($item->id); ?>" onclick="document.getElementById('li-<?php echo e($item->id); ?>').click(); ">
                            </li>    
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                    <button class="col-6 btn btn-success">Сохранить</button>
                </form>
            <?php endif; ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\maxim\OneDrive\Рабочий стол\git\my-audio-lib\resources\views/select-reader.blade.php ENDPATH**/ ?>