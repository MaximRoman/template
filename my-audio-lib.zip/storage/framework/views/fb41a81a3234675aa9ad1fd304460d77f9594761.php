

<?php $__env->startSection('content'); ?>
    <div class="card border-0 h-100 rounded-0 bg-gray">
        <div class="card-body">
            <h3 class="text-center">Загрузка Аудио Файлов Книги :</h3>
            <h5 class="text-warning text-center">!!!ВНИМАНИЕ!!!</h5>
            <h5 class="text-center"><span class="text-danger">Если у этой книги уже существуют аудио файлы, то они будут удалены!</span></h5>
            <multy-upload card='bg-secondary text-light' childs='bg-gray text-light' :obj="<?php echo e($book); ?>"></multy-upload>
            
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\maxim\OneDrive\Рабочий стол\git\my-audio-lib\resources\views/upload-files.blade.php ENDPATH**/ ?>