<?php $__env->startSection('content'); ?>
    <?php $__empty_1 = true; $__currentLoopData = $books; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
    <div class="card bg-gray border-success">
        <div class="card-header d-flex justify-content-between align-items-center border-success">
            <h3 class="text-center w-100"><?php echo e($item->title); ?></h3>
            <div class="d-flex gap-2">
                <a  href=<?php echo e(route('editBook')); ?>></a>
                <form action="<?php echo e(route('editBook')); ?>" method="GET">
                    <button class="btn btn-warning" type="submit"><i class="fa-solid fa-pen"></i></button>
                </form>
                <form action='/delete-book/<?php echo e($item->id); ?>' method="POST">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('delete'); ?>
                    <button class="btn btn-danger" type="submit"><i class="fa-solid fa-trash"></i></button>
                </form>
            </div>
        </div>
        <div class="card-body">
            
            <h5>Год : <span class="text-primary"><?php echo e($item->year); ?></span></h5>
            <div class="">
                <h5>Описание :</h5>
                <p><?php echo e($item->description); ?></p>
            </div>
        </div>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <h3 class="text-center">Нет книг в базе, <a href="/add-book">добавить новую книгу</a></h3>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\maxim\OneDrive\Рабочий стол\с\laravel\resources\views/index.blade.php ENDPATH**/ ?>