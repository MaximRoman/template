

<?php $__env->startSection('content'); ?>
    <div class="row gap-1">
        <label for="book-files">Выберите Аудио Файлы Книги</label>
        <multy-upload id="book-files"></multy-upload>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\maxim\OneDrive\Рабочий стол\с\laravel\resources\views/upload-files.blade.php ENDPATH**/ ?>