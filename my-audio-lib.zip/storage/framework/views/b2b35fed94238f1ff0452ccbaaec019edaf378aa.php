

<?php $__env->startSection('content'); ?>
    <div class="card border-0 h-100 rounded-0 bg-gray">
        <div class="card-body">
            <h3 class="text-center">Выбор обложки книги :</h3>
            <div class="h3 d-flex justify-content-between gap-3">
                <?php if(isset($bookId)): ?>
                    <a class="btn btn-success" href="/edit-book/<?php echo e($bookId); ?>"><i class="fa-solid fa-arrow-left"></i></a>
                    <a class="btn btn-success" href="/add-image/<?php echo e($bookId); ?>"><i class="fa-solid fa-plus"></i></a>
                <?php else: ?>
                    <a class="btn btn-success" href="/add-book"><i class="fa-solid fa-arrow-left"></i></a>
                    <a class="btn btn-success" href="/add-image"><i class="fa-solid fa-plus"></i></a>
                <?php endif; ?>
            </div>
            <?php if(isset($images)): ?>
                <?php if(isset($bookId)): ?>
                <images-list :images="<?php echo e($images); ?>" url="/edit-book/<?php echo e($bookId); ?>/select-book-image/"></images-list>
                <?php else: ?>
                <images-list :images="<?php echo e($images); ?>" url="/add-book/select-book-image/"></images-list>
                <?php endif; ?>    
            <?php endif; ?>
            
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\maxim\OneDrive\Рабочий стол\git1\my-audio-lib\resources\views/book views/image/select-image.blade.php ENDPATH**/ ?>