

<?php $__env->startSection('content'); ?>
    <div class="card border-0 h-100 rounded-0 bg-gray">
        <div class="card-body">
            <h3 class="text-center">Загрузка Аудио Файлов Книги :</h3>
            <div class="h3 d-flex justify-content-between">
                <a class="btn btn-success" href="/edit-book/<?php echo e($bookId); ?>"><i class="fa-solid fa-arrow-left"></i></a>
            </div>
            <multy-upload card='bg-secondary text-light' childs='bg-gray text-light' :obj="<?php echo e($book); ?>"></multy-upload>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\maxim\OneDrive\Рабочий стол\git1\my-audio-lib\resources\views/book views/book elements/upload-files.blade.php ENDPATH**/ ?>