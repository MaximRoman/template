

<?php $__env->startSection('content'); ?>
    <div class="card border-0 h-100 rounded-0 bg-gray">
        <div class="card-body">
            <h3 class="text-center">Выбор обложки книги : <a class="btn btn-success" href="/add-image"><i class="fa-solid fa-plus"></i></a></h3>
            <?php if(isset($images)): ?>
                <div class="row gap-3 justify-content-center mt-3">
                    <?php $__currentLoopData = $images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <img class="col-3 img-fluid " src="<?php echo e(asset('/storage/' . $item->image)); ?>" onclick="event.preventDefault(); document.getElementById('image-<?php echo e($item->id); ?>').submit();">
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <?php $__currentLoopData = $images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <form id="image-<?php echo e($item->id); ?>" action="/add-book/select-image/<?php echo e($item->id); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                    </form>                        
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\maxim\OneDrive\Рабочий стол\с\laravel\resources\views/select-image.blade.php ENDPATH**/ ?>