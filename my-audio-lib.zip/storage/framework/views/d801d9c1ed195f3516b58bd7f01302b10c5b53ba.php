

<?php $__env->startSection('content'); ?>
    <div class="d-flex flex-column-reverse">
        <?php $__empty_1 = true; $__currentLoopData = $books; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <form id="book-<?php echo e($item->id); ?>" action="/book/<?php echo e($item->id); ?>"></form>
        <div class="card bg-gray border-success mb-3">
            <div class="card-header d-flex justify-content-between align-items-center border-success">
                <h4 class="text-center w-100"  style="cursor: pointer;" onclick="event.preventDefault(); document.getElementById('book-<?php echo e($item->id); ?>').submit();"><?php echo e($item->title); ?></h4>
                <div class="d-flex gap-2">
                    <form action="/edit-book/<?php echo e($item->id); ?>">
                        <button class="btn btn-warning h4" type="submit"><i class="fa-solid fa-pen"></i></button>
                    </form>
                    <form action='/delete-book/<?php echo e($item->id); ?>' method="POST">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('delete'); ?>
                        <button class="btn btn-danger h4" type="submit"><i class="fa-solid fa-trash"></i></button>
                    </form>
                </div>
            </div>
            <div class="card-body row">
                <div class="col-4">
                    <?php $__currentLoopData = $images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($item->id === $image->book_id): ?>
                            <img class="img-fluid" src="<?php echo e(asset('/storage/' . $image->image)); ?>"  style="cursor: pointer;" onclick="event.preventDefault(); document.getElementById('book-<?php echo e($item->id); ?>').submit();">
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <div class="col-8">
                    <div class="m-0">
                        <span class="h5 me-2">Автор :</span>
                        <?php $__currentLoopData = $authors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $author): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($item->id === $author->book_id): ?>
                                <a class="my-link h5 text-success" href="/"><?php echo e($author->author); ?></a>
                                <?php if($loop->index < count($authors) - 1): ?>
                                    <span class="h5 me-2">,</span>
                                <?php endif; ?>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                    <div class="mt-3">
                        <span class="h5 me-2">Читает :</span>
                        <?php $__currentLoopData = $readers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $reader): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($item->id === $reader->book_id): ?>
                                <a class="my-link h5 text-success" href="/"><?php echo e($reader->reader); ?></a>
                                <?php if($loop->index < count($readers) - 1): ?>
                                    <span class="h5 me-2">,</span>
                                <?php endif; ?>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                    <div class="mt-3">
                        <span class="h5 me-2">Год :</span>
                        <span class="h5 text-primary"><?php echo e($item->year); ?></span>
                    </div>
                    <div class="mt-3">
                        <span class="h5 me-2">Цыкл :</span>
                        <?php $__currentLoopData = $series; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $seriesItem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($item->id === $seriesItem->book_id): ?>
                                <a class="my-link h5 text-success" href="/"><?php echo e($seriesItem->series); ?></a>
                                
                                <?php break; ?>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                    <div class="mt-3">
                        <span class="h5 me-2">Категория :</span>
                        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($item->id === $category->book_id): ?>
                                <a class="my-link h5 text-success" href="/"><?php echo e($category->category); ?></a>
                                <?php if($loop->index < count($categories) - 1): ?>
                                    <span class="h5 me-1 ms-1">/</span>
                                <?php endif; ?>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                    <div class="mt-3">
                        <span class="h5 me-2">Описание :</span>
                        <p  style="cursor: pointer;" onclick="event.preventDefault(); document.getElementById('book-<?php echo e($item->id); ?>').submit();">
                            <?php $__currentLoopData = explode(' ', $item->description); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $str): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($loop->index < 30): ?>
                                    <?php echo e($str); ?>

                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            ....
                        </p>
                    </div>
                </div>
            </div>
            <div class="card-footer border-success d-flex justify-content-between">
                <like-system :book="<?php echo e(json_encode($item)); ?>" :user="<?php echo e(json_encode($user)); ?>"></like-system>
                
                <button class="btn btn-success" onclick="event.preventDefault(); document.getElementById('book-<?php echo e($item->id); ?>').submit();">Подробнее</button>
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <h3 class="text-center">Нет книг в базе, <a href="/add-book">добавить новую книгу</a></h3>
        <?php endif; ?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\maxim\OneDrive\Рабочий стол\Новая папка (9)\my-audio-lib\resources\views/index.blade.php ENDPATH**/ ?>