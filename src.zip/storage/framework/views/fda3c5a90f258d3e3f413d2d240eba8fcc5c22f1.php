

<?php $__env->startSection('content'); ?>
    <div class="d-flex flex-column-reverse">
        <div class="card bg-gray border-success mb-3 border-0" >
            <div class="card-body row justify-content-start">
                <div class="mb-3">
                    <edit-delete-btns class="d-flex justify-content-between" :book="<?php echo e($book->id); ?>" :admin-prop="<?php echo e(json_encode($admin)); ?>"></edit-delete-btns>
                    <h4 class="text-center"><?php echo e($book->title); ?> </h4>
                </div>
                <div class="col-md-auto col-12  d-flex justify-content-center">
                    <?php $__currentLoopData = $images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($book->id === $image->book_id): ?>
                            <img class="h-300px" src="<?php echo e('https://laravelmyaudiolib.s3.amazonaws.com/' . $image->image); ?>">
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <div class="col-lg-8 col-md-6 d-flex flex-column justify-content-between gap-3">
                    <div>
                        <div class="m-0">
                            <span class="h5 me-2">Автор:</span>
                            <?php $__currentLoopData = $authors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $author): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($book->id === $author->book_id): ?>
                                    <a class="my-link h5 text-success" href="/search/<?php echo e($author->author); ?>/"><?php echo e($author->author); ?></a>
                                    <span class="h5 me-2">,</span>
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                        <div class="mt-3">
                            <span class="h5 me-2">Читает:</span>
                            <?php $__currentLoopData = $readers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $reader): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($book->id === $reader->book_id): ?>
                                    <a class="my-link h5 text-success" href="/search/<?php echo e($reader->reader); ?>/"><?php echo e($reader->reader); ?></a>
                                    <span class="h5 me-2">,</span>
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                        <div class="mt-3">
                            <span class="h5 me-2">Год:</span>
                            <span class="h5 text-primary"><?php echo e($book->year); ?></span>
                        </div>
                        <div class="mt-3">
                            <span class="h5 me-2">Длительность:</span>
                            <?php $__currentLoopData = $duration; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($book->id === $item->book_id): ?>
                                    <audio-duration class="h5 text-primary" :duration-value="<?php echo e($item->duration); ?>"></audio-duration>
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                        
                        <div class="mt-3">
                            <span class="h5 me-2">Категория:</span>
                            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($book->id === $category->book_id): ?>
                                <a class="my-link h5 text-success" href="/category/<?php echo e($category->temp_category); ?>/"><?php echo e($category->category); ?></a>
                                <span class="h5 me-1 ms-1">,</span>
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                </div>
                <div class="mt-3">
                        <span class="h5 me-2">Описание:</span>
                        <p><?php echo e($book->description); ?></p>
                </div>
                
                <div class="mt-3 d-flex justify-content-between">
                    <add-to-fav :book="<?php echo e($book->id); ?>" :user-id="<?php echo e(json_encode($userId)); ?>"></add-to-fav>
                    <like-book :book="<?php echo e(json_encode($book)); ?>" :user="<?php echo e(json_encode($user)); ?>" :btn="<?php echo e(json_encode(true)); ?>"></like-book>
                </div>
                <audio-player class="mt-5" :file="<?php echo e($files); ?>"></audio-player>
                <comments-system class="mt-5" :book="<?php echo e($book->id); ?>" :user="<?php echo e($user); ?>"></comments-system>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\maxim\OneDrive\Рабочий стол\host\It-Step-Examen-Final\src\resources\views/book views/book/book-index.blade.php ENDPATH**/ ?>