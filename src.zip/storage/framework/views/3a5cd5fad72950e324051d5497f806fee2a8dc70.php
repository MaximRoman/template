

<?php $__env->startSection('content'); ?>
    <div class="card border-0 h-100 rounded-0 bg-gray">
        <div class="card-body">
            <h3 class="text-center">Изменить Информацыю о книге :</h3>
            <div class="row justify-content-center gap-3">
                <a class="col-7 btn btn-success" href=<?php echo e(route('editBookInfo')); ?>>Изменить Название, Год или Описание Книги</a>
                <a class="col-7 btn btn-success" href=<?php echo e(route('editBookImage')); ?>>Изменить Обложку Книги</a>
                <a class="col-7 btn btn-success" href=<?php echo e(route('editBookAuthors')); ?>>Изменить список Авторов Книги</a>
                <a class="col-7 btn btn-success" href=<?php echo e(route('editBookReaders')); ?>>Изменить список Читателей Книги</a>
                <a class="col-7 btn btn-success" href=<?php echo e(route('editBookCategories')); ?>>Изменить список Категорий Книги</a>
                <a class="col-7 btn btn-success" href=<?php echo e(route('editBookFiles')); ?>>Изменить Аудио Файлы Книги</a>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\maxim\OneDrive\Рабочий стол\с\laravel\resources\views/edit-book.blade.php ENDPATH**/ ?>