

<?php $__env->startSection('content'); ?>
    <div class="card border-0 h-100 rounded-0 bg-gray">
        <div class="card-body">
            <h3 class="text-center">Сменить / Удалить Обложку :</h3>
            <div class="h3 d-flex justify-content-between gap-3">
                <?php if(isset($bookId)): ?>
                    <a class="btn btn-success" href="/edit-book/<?php echo e($bookId); ?>/select-book-image"><i class="fa-solid fa-arrow-left"></i></a>
                <?php else: ?>
                    <a class="btn btn-success" href="/add-book/select-image"><i class="fa-solid fa-arrow-left"></i></a>
                <?php endif; ?>
            </div>
            <?php if(isset($_GET['message'])): ?>
                <p class="h5 text-center text-danger"><?php echo e($_GET['message']); ?></p>
            <?php endif; ?>
            <div class="row justify-content-center">
                <div class="col-4 ">
                    <?php $__currentLoopData = $images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <form action="/delete-image/<?php echo e($item->id); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field("PUT"); ?>
                            <button class="btn btn-danger rounded-0 rounded-top w-100" type="submit"><i class="fa-solid fa-trash"></i></button>
                        </form>
                        <img class="img-fluid" src="<?php echo e('https://laravelmyaudiolib.s3.amazonaws.com/' . $item->image); ?>" alt="">
                        <h5 class="bg-secondary m-0 p-1"><?php echo e($item->name); ?></h5>
                        <form id="image-edit-form" action="/upload-other-image/<?php echo e($item->id); ?>" method="POST" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('PUT'); ?>
                            <label class="btn btn-warning rounded-0 rounded-bottom w-100" for="file"><i class="fa-solid fa-pen"></i><input class="form-control bg-secondary text-light invisible" type="file" name="file" id="file" accept="image/*" oninput="document.getElementById('image-edit-form').submit()"></label>
                        </form>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\maxim\OneDrive\Рабочий стол\git1\my-audio-lib\resources\views/book views/image/edit-image.blade.php ENDPATH**/ ?>