

<?php $__env->startSection('content'); ?>
    <div class="d-flex flex-column-reverse">
        <div class="card bg-gray border-success mb-3 border-0" >
            <div class="card-body row justify-content-center">
                <div class="mb-3 d-flex">
                    <h4 class="text-center w-100"><?php echo e($book->title); ?></h4>
                    <div class="d-flex gap-2">
                        <form action="/edit-book/<?php echo e($book->id); ?>">
                            <button class="btn btn-warning h4" type="submit"><i class="fa-solid fa-pen"></i></button>
                        </form>
                        <form action='/delete-book/<?php echo e($book->id); ?>' method="POST">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('delete'); ?>
                            <button class="btn btn-danger h4" type="submit"><i class="fa-solid fa-trash"></i></button>
                        </form>
                    </div>
                </div>
                <div class="col-4">
                    <?php $__currentLoopData = $images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($book->id === $image->book_id): ?>
                            <img class="img-fluid" src="<?php echo e(asset('/storage/' . $image->image)); ?>">
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <div class="col-8">
                    <div class="m-0">
                        <span class="h5 me-2">Автор :</span>
                        <?php $__currentLoopData = $authors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $author): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($book->id === $author->book_id): ?>
                                <span class="h5 text-success"><?php echo e($author->author); ?></span>
                                <?php if($loop->index < count($authors) - 1): ?>
                                    <span class="h5 me-2">,</span>
                                <?php endif; ?>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                    <div class="mt-3">
                        <span class="h5 me-2">Читает :</span>
                        <?php $__currentLoopData = $readers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $reader): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($book->id === $reader->book_id): ?>
                                <span class="h5 text-success"><?php echo e($reader->reader); ?></span>
                                <?php if($loop->index < count($readers) - 1): ?>
                                    <span class="h5 me-2">,</span>
                                <?php endif; ?>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                    <div class="mt-3">
                        <span class="h5 me-2">Год :</span>
                        <span class="h5 text-primary"><?php echo e($book->year); ?></span>
                    </div>
                    <div class="mt-3">
                        <span class="h5 me-2">Длительность :</span>
                        <audio-duration class="h5 text-primary" :obj="<?php echo e($duration); ?>"></audio-duration>
                    </div>
                    <div class="mt-3">
                        <span class="h5 me-2">Оценка :</span>
                        <calc-grade :book="<?php echo e($book->id); ?>"></calc-grade>
                    </div>
                    <div class="mt-3">
                        <span class="h5 me-2">Цыкл :</span>
                        <?php $__currentLoopData = $series; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $seriesItem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($book->id === $seriesItem->book_id): ?>
                                <span class="h5 text-success"><?php echo e($seriesItem->series); ?></span>
                                
                                <?php break; ?>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                    <div class="mt-3">
                        <span class="h5 me-2">Категория :</span>
                        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($book->id === $category->book_id): ?>
                                <span class="h5 text-success"><?php echo e($category->category); ?></span>
                                <?php if($loop->index < count($categories) - 1): ?>
                                    <span class="h5 me-1 ms-1">/</span>
                                <?php endif; ?>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                    <div class="d-flex justify-content-end">
                        <like-book class="mt-1" :book="<?php echo e(json_encode($book)); ?>" :user="<?php echo e(json_encode($user)); ?>" :btn="<?php echo e(json_encode(false)); ?>"></like-book>
                    </div>
                </div>
                <div class="mt-3">
                        <span class="h5 me-2">Описание :</span>
                        <p><?php echo e($book->description); ?></p>
                </div>
                <audio-player class="mt-5" :file="<?php echo e($files); ?>"></audio-player>
                <comments-system class="mt-5" :book="<?php echo e($book->id); ?>" :user="<?php echo e($user); ?>"></comments-system>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\maxim\OneDrive\Рабочий стол\git\my-audio-lib\resources\views/book views/book/book-index.blade.php ENDPATH**/ ?>