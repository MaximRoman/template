

<?php $__env->startSection('content'); ?>
    <div class="card border-0 h-100 rounded-0 bg-gray">
        <div class="card-body">
            <h3 class="text-center">Добавить нового Читателя :</h3>
            <div class="h3 d-flex justify-content-between">
                <?php if(isset($bookId)): ?>
                    <a class="btn btn-success" href="/edit-book/<?php echo e($bookId); ?>/select-reader"><i class="fa-solid fa-arrow-left"></i></a>
                <?php else: ?>
                    <a class="btn btn-success" href="/add-book/select-reader"><i class="fa-solid fa-arrow-left"></i></a>
                <?php endif; ?>
            </div>
            <form class="form-group row justify-content-center gap-3" action=<?php echo e(route('createReader')); ?> method="POST">
                <?php echo csrf_field(); ?>
                <?php if(isset($bookId)): ?>
                    <input type="hidden" name="bookId" value="<?php echo e($bookId); ?>">
                <?php endif; ?>
                <div class="col-7">
                    <label for="reader">Читатель</label>
                    <input class="form-control bg-secondary text-light <?php $__errorArgs = ['reader'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" type="text" name="reader" id="reader">
                    <?php $__errorArgs = ['reader'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="invalid-feedback" role="alert">
                            <strong><?php echo e($message); ?></strong>
                        </span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <button class="col-6 btn btn-success" type="submit">Добавить</button>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\maxim\OneDrive\Рабочий стол\git1\my-audio-lib\resources\views/book views/reader/add-reader.blade.php ENDPATH**/ ?>