

<?php $__env->startSection('content'); ?>
    <div class="card rounded-0 bg-gray h-100 border-0">
        <div class="card-body">
            <h3 class="text-center">Проверьте свой адрес электронной почты:</h3>
            <br>
            <?php if(session('resent')): ?>
                <div class="alert alert-success" role="alert">
                    <?php echo e(__('A fresh verification link has been sent to your email address.')); ?>

                </div>
            <?php endif; ?>
            <?php echo e(__('Прежде чем продолжить, проверьте свою электронную почту на наличие ссылки для подтверждения.')); ?>

            <?php echo e(__('Если вы не получили письмо')); ?>,
            <form class="d-inline" method="POST" action="<?php echo e(route('verification.resend')); ?>">
                <?php echo csrf_field(); ?>
                <button type="submit" class="btn btn-link p-0 m-0 align-baseline"><?php echo e(__('нажмите здесь, чтобы запросить ссылку ещё раз')); ?></button>.
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\maxim\OneDrive\Рабочий стол\git1\my-audio-lib\resources\views/auth/verify.blade.php ENDPATH**/ ?>