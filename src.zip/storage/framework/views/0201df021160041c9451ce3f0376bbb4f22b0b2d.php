

<?php $__env->startSection('content'); ?>
    <div class="card border-0 h-100 rounded-0 bg-gray">
        <div class="card-body">
            <h3 class="text-center">Изменить Данные Книги :</h3>
            <form class="form-group row justify-content-center" action="/">
                <div class="col-4 h-100 p-0 m-0">
                    <div class="d-flex flex-column align-items-start gap-2">
                        <label>Обложка</label>
                        <?php if(isset($image)): ?>
                            <?php if(count($image) > 0): ?>
                                <div class="row">
                                    <div class="col-12">
                                        <?php $__currentLoopData = $image; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <img class="img-fluid rounded-top" src="<?php echo e(asset('/storage/' . $item->image)); ?>">
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <a class="btn btn-warning w-100 rounded-0 rounded-bottom" href="/edit-book/<?php echo e($bookId); ?>/select-image"><i class="fa-solid fa-pen"></i></a>    
                                    </div>
                                </div>
                            <?php else: ?>
                                <a class="btn btn-success" href="/edit-book/<?php echo e($bookId); ?>/select-image"><i class="fa-solid fa-plus"></i></a>    
                            <?php endif; ?>   
                        <?php endif; ?>        
                    </div>
                </div>
                <div class="col-8 row justify-content-start  p-0 m-0">
                    <div class="col-12 d-flex flex-column align-items-start">
                        <label>Название</label>
                        <?php if(isset($book)): ?>
                            <?php if(count($book) > 0): ?>
                                <div>
                                    <?php $__currentLoopData = $book; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <span class="h4 text-success"><?php echo e($item->title); ?></span>                
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <a class="btn btn-warning ms-2 h4" href="/edit-book/<?php echo e($bookId); ?>/select-title"><i class="fa-solid fa-pen"></i></a>
                                </div>
                            <?php else: ?>
                                <a class="btn btn-success" href="/edit-book/<?php echo e($bookId); ?>/select-title"><i class="fa-solid fa-plus"></i></a>
                            <?php endif; ?>
                        <?php endif; ?>
                    </div>
                    <div class="col-12 d-flex flex-column align-items-start">
                        <label>Автор</label>
                        <?php if(isset($authors)): ?>
                            <?php if(count($authors) > 0): ?>
                                <div>
                                    <?php $__currentLoopData = $authors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <span class="h4 text-success"><?php echo e($item->author); ?></span>
                                        <?php if($loop->index < count($authors) - 1): ?>
                                            <span class="h4 me-2">,</span>
                                        <?php endif; ?>                              
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <a class="btn btn-warning ms-2 h4" href="/edit-book/<?php echo e($bookId); ?>/select-author"><i class="fa-solid fa-pen"></i></a>
                                </div>
                            <?php else: ?>
                                <a class="btn btn-success" href="/edit-book/<?php echo e($bookId); ?>/select-author"><i class="fa-solid fa-plus"></i></a>
                            <?php endif; ?>
                        <?php endif; ?>
                    </div>
                    <div class="col-12 d-flex flex-column align-items-start">
                        <label>Читает</label>
                        <?php if(isset($readers)): ?>
                            <?php if(count($readers) > 0): ?>
                                <div>
                                    <?php $__currentLoopData = $readers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <span class="h4 w-100 text-success"><?php echo e($item->reader); ?></span>
                                        <?php if($loop->index < count($readers) - 1): ?>
                                            <span class="h4 me-2">,</span>
                                        <?php endif; ?>                              
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                                    <a class="btn btn-warning ms-2 h4" href="/edit-book/<?php echo e($bookId); ?>/select-reader"><i class="fa-solid fa-pen"></i></a>
                                </div>
                           <?php else: ?>
                                <a class="btn btn-success" href="/edit-book/<?php echo e($bookId); ?>/select-reader"><i class="fa-solid fa-plus"></i></a>
                            <?php endif; ?>
                        <?php endif; ?>
                    </div>
                    <div class="col-12 d-flex flex-column align-items-start">
                        <label>Год</label>
                        <?php if(isset($book)): ?>
                            <?php if(count($book) > 0): ?>
                                <div>
                                    <?php $__currentLoopData = $book; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <span class="h4 text-success"><?php echo e($item->year); ?></span>                
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <a class="btn btn-warning ms-2 h4" href="/edit-book/<?php echo e($bookId); ?>/select-year"><i class="fa-solid fa-pen"></i></a>
                                </div>
                            <?php else: ?>
                            <a class="btn btn-success" href="/edit-book/<?php echo e($bookId); ?>/select-year"><i class="fa-solid fa-plus"></i></a>
                            <?php endif; ?>
                        <?php endif; ?>
                    </div>
                    <div class="col-12 d-flex flex-column align-items-start">
                        <label>Цыкл</label>
                        <?php if(isset($series)): ?>
                            <?php if(count($series) > 0): ?>
                                <div class="d-flex flex-warp mw-100 gap-1">
                                    <?php $__currentLoopData = $series; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <span class="h4 text-success"><?php echo e($item->series); ?></span>
                                        <?php if($loop->index < count($series) - 1): ?>
                                            <span class="h4 me-1 ms-1">/</span>
                                        <?php endif; ?>                              
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <a class="btn btn-warning ms-2 h4" href="/edit-book/<?php echo e($bookId); ?>/select-series"><i class="fa-solid fa-pen"></i></a>
                                </div>
                            <?php else: ?>
                            <a class="btn btn-success" href="/edit-book/<?php echo e($bookId); ?>/select-series"><i class="fa-solid fa-plus"></i></a>
                            <?php endif; ?>
                        <?php endif; ?>
                    </div>
                    <div class="col-12 d-flex flex-column align-items-start">
                        <label>Категория</label>
                        <?php if(isset($categories)): ?>
                            <?php if(count($categories) > 0): ?>
                                <div>
                                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <span class="h4 text-success"><?php echo e($item->category); ?></span>
                                        <?php if($loop->index < count($categories) - 1): ?>
                                            <span class="h4 me-1 ms-1">/</span>
                                        <?php endif; ?>                              
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <a class="btn btn-warning ms-2 h4" href="/edit-book/<?php echo e($bookId); ?>/select-category"><i class="fa-solid fa-pen"></i></a>
                                </div>
                            <?php else: ?>
                                <a class="btn btn-success" href="/edit-book/<?php echo e($bookId); ?>/select-category"><i class="fa-solid fa-plus"></i></a>
                            <?php endif; ?>
                        <?php endif; ?>
                    </div>
                </div>
                <div class="col-12 p-0 m-0 mt-3">
                    
                    <?php if(isset($book)): ?>
                        <?php if(count($book) > 0): ?>
                            <label class="w-100 d-flex justify-content-between align-items-center mb-1"><span>Описание</span> <a class="btn btn-warning" href="/edit-book/<?php echo e($bookId); ?>/select-description"><i class="fa-solid fa-pen"></i></a></label>
                            <?php $__currentLoopData = $book; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <textarea class="form-control bg-secondary text-light <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="description" id="description" cols="30" rows="10" disabled><?php echo e($item->description); ?></textarea>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php else: ?>
                            <label class="w-100 d-flex justify-content-between align-items-center mb-1"><span>Описание</span> <a class="btn btn-success" href="/edit-book/<?php echo e($bookId); ?>/select-description"><i class="fa-solid fa-plus"></i></a></label>
                            <textarea class="form-control bg-secondary text-light <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="description" id="description" cols="30" rows="10" disabled></textarea>
                        <?php endif; ?>
                    <?php endif; ?>
                    
                </div>
                <a class="btn btn-warning mt-3" href="/edit-book/<?php echo e($bookId); ?>/upload-files">Изменить Аудио файлы Книги</a>
                <button type="submit" class="col-6 btn btn-success mt-3">Сохранить</button>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\maxim\OneDrive\Рабочий стол\git\my-audio-lib\resources\views/book views/book/edit-book.blade.php ENDPATH**/ ?>