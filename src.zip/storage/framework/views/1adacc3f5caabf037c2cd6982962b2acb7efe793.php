

<?php $__env->startSection('content'); ?>
    <div class="d-flex flex-column">
        <?php $__empty_1 = true; $__currentLoopData = $books; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <form id="book-<?php echo e($item->id); ?>" action="/book/<?php echo e($item->id); ?>"></form>
        <div class="card bg-gray border-success mb-3">
            <div class="card-header border-success">
                <div class="">
                    <edit-delete-btns class="d-flex justify-content-between" :book="<?php echo e($item->id); ?>" :admin-prop="<?php echo e(json_encode($admin)); ?>"></edit-delete-btns>
                    <h4 class="m-0 p-0 text-center"  style="cursor: pointer;"  onclick="event.preventDefault(); document.getElementById('book-<?php echo e($item->id); ?>').submit();"><?php echo e($item->title); ?> </h4>
                </div>
            </div>
            <div class="card-body row justify-content-start">
                <div class="col-md-auto col-12 d-flex justify-content-center">
                    <?php $__currentLoopData = $images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($item->id === $image->book_id): ?>
                            <img src="<?php echo e('https://laravelmyaudiolib.s3.amazonaws.com/' . $image->image); ?>"  style="cursor: pointer; height: 300px; width: 200px;" onclick="event.preventDefault(); document.getElementById('book-<?php echo e($item->id); ?>').submit();">
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <div class="col-lg-8 col-md-6">
                    <div class="m-0">
                        <span class="h5 me-2">Автор:</span>
                        <?php $__currentLoopData = $authors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $author): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($item->id === $author->book_id): ?>
                                <a class="my-link h5 text-success" href="/search/<?php echo e($author->author); ?>/"><?php echo e($author->author); ?></a>
                                <?php if($loop->index < count($authors) - 1): ?>
                                    <span class="h5 me-2">,</span>
                                <?php endif; ?>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                    <div class="mt-3">
                        <span class="h5 me-2">Читает:</span>
                        <?php $__currentLoopData = $readers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $reader): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($item->id === $reader->book_id): ?>
                                <a class="my-link h5 text-success" href="/search/<?php echo e($reader->reader); ?>/"><?php echo e($reader->reader); ?></a>
                                <?php if($loop->index < count($readers) - 1): ?>
                                    <span class="h5 me-2">,</span>
                                <?php endif; ?>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                    <div class="mt-3">
                        <span class="h5 me-2">Длительность:</span>
                        <?php $__currentLoopData = $duration; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $durationItem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($item->id === $durationItem->book_id): ?>
                                <audio-duration class="h5 text-primary" :duration-value="<?php echo e($durationItem->duration); ?>"></audio-duration>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                    
                    <div class="mt-3">
                        <span class="h5 me-2">Категория:</span>
                        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($item->id === $category->book_id): ?>
                                <a class="my-link h5 text-success" href="/category/<?php echo e($category->temp_category); ?>/"><?php echo e($category->category); ?></a>
                                <span class="h5 me-1 ms-1">/</span>
                                
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                    <div class="mt-3">
                        <span class="h5 me-2">Описание:</span>
                        <p  style="cursor: pointer;" onclick="event.preventDefault(); document.getElementById('book-<?php echo e($item->id); ?>').submit();">
                            <?php $__currentLoopData = explode(' ', $item->description); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $str): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($loop->index < 30): ?>
                                    <?php echo e($str); ?>

                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            ....
                        </p>
                    </div>
                </div>
            </div>
            <div class="card-footer border-success d-flex justify-content-between">
                <like-book :book="<?php echo e(json_encode($item)); ?>" :user="<?php echo e(json_encode($user)); ?>" :btn="<?php echo e(json_encode(true)); ?>"></like-book>
                
                <button class="btn btn-success" onclick="event.preventDefault(); document.getElementById('book-<?php echo e($item->id); ?>').submit();">Подробнее</button>
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <?php if(isset($message)): ?>
                <div class="card bg-gray border-success mb-3">
                    <div class="card-body">
                        <p class="h3 text-center text-danger"><?php echo e($message); ?></p>
                    </div>
                </div>
            <?php else: ?> 
                <h3 class="text-center text-danger">! Нет книг в базе !</h3>
            <?php endif; ?>
        <?php endif; ?>
        <?php if($totalPages > 1): ?>
            <div class="d-flex justify-content-between mt-5">   
                <div class="d-flex col-2">                    
                    <?php if($page == 1): ?>
                        <button class="w-100 btn btn-outline-success" type="submit" <?php if(true): echo 'disabled'; endif; ?>><i class="fa-solid fa-arrow-left"></i></button>
                    <?php else: ?>
                        <a class="w-100 btn btn-outline-success d-flex align-items-center justify-content-center" href="/<?php echo e($link); ?>page/<?php echo e($page - 1); ?>"><i class="fa-solid fa-arrow-left"></i></a>
                    <?php endif; ?> 
                </div>
                <div class="d-flex gap-2">
                    
                    <h3 class="text-success"><?php echo e($page); ?> / <?php echo e($totalPages); ?></h3>
                </div>
                <div class="d-flex gap-2 col-2">
                    <?php if($page == $totalPages): ?>
                        <button class="w-100 btn btn-outline-success" type="submit" <?php if(true): echo 'disabled'; endif; ?>><i class="fa-solid fa-arrow-right"></i></button>
                    <?php else: ?>
                        <a class="w-100 btn btn-outline-success d-flex align-items-center justify-content-center" href="/<?php echo e($link); ?>page/<?php echo e($page + 1); ?>"><i class="fa-solid fa-arrow-right"></i></a>
                    <?php endif; ?>
                </div>
            </div>
        <?php endif; ?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\maxim\OneDrive\Рабочий стол\host\It-Step-Examen-Final\src\resources\views/index.blade.php ENDPATH**/ ?>