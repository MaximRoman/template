

<?php $__env->startSection('content'); ?>
    <div class="card border-0 h-100 rounded-0 bg-gray">
        <div class="card-body">
            <h3 class="text-center">Описание Книги :</h3>
            
            <?php if(isset($bookId)): ?>
                <form class="row gap-3 justify-content-center mt-3" action="/edit-book/<?php echo e($bookId); ?>/select-book-description" method="POST">
            <?php else: ?>
                <form class="row gap-3 justify-content-center mt-3" action=<?php echo e(route('selectBookDescription')); ?> method="POST">
            <?php endif; ?>
                <?php echo csrf_field(); ?>
                <div class="col-7">
                    <label for="description">Описание</label>
                    <textarea class="form-control bg-secondary text-light <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="description" id="description" cols="30" rows="10"></textarea>
                    <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="invalid-feedback" role="alert">
                            <strong><?php echo e($message); ?></strong>
                        </span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <button class="col-6 btn btn-success" type="submit">Сохранить</button>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>
                        
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\maxim\OneDrive\Рабочий стол\git\my-audio-lib\resources\views/select-description.blade.php ENDPATH**/ ?>