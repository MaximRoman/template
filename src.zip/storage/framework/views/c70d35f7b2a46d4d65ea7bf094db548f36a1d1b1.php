

<?php $__env->startSection('content'); ?>
    <div class="card border-0 h-100 rounded-0 bg-gray">
        <div class="card-body">
            <h3 class="text-center">Выбор Категорий Книги : </h3>
            <div class="h3 d-flex justify-content-between gap-3">
                <?php if(isset($bookId)): ?>
                    <a class="btn btn-success" href="/edit-book/<?php echo e($bookId); ?>"><i class="fa-solid fa-arrow-left"></i></a>
                    
                <?php else: ?>
                    <a class="btn btn-success" href="/add-book"><i class="fa-solid fa-arrow-left"></i></a>
                    
                <?php endif; ?>
            </div>
            <?php if(isset($categories)): ?>
                <list-item  class="mt-3"
                    list-name="Список Категорий :" 
                    :items="<?php echo e(json_encode($categories)); ?>" 
                    name-input="category" 
                    type-input="checkbox" 
                    empty-message="Нет Авторов в Базе" 
                    url="/add-book/select-book-category">
                </list-item>
                <?php if(isset($bookId)): ?>
                    <form class="row justify-content-center mt-3" action="/edit-book/<?php echo e($bookId); ?>/select-book-category" method="POST">
                        <?php echo csrf_field(); ?>
                <?php else: ?>
                    <form class="row justify-content-center mt-3" action="/add-book">
                <?php endif; ?>
                    <button class="btn btn-success col-6" type="submit">Выбрать</button>
                </form>
            <?php endif; ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\maxim\OneDrive\Рабочий стол\git1\my-audio-lib\resources\views/book views/category/select-category.blade.php ENDPATH**/ ?>